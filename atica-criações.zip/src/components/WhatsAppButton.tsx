import React from "react";

interface WhatsAppButtonProps {
  highContrast?: boolean;
}

export default function WhatsAppButton({ highContrast }: WhatsAppButtonProps) {
  const phoneNumber = "5511970199648";
  const message = "Olá, venho do site da Atica Criações e gostaria de saber mais.";
  const encodedText = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedText}`;

  // Custom standard SVG for WhatsApp
  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center group">
      {/* Tooltip / Label */}
      <span className={`mr-3 px-3 py-1.5 text-xs font-sans tracking-wide rounded-lg opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 pointer-events-none shadow-md border ${
        highContrast 
          ? "bg-black text-white border-white" 
          : "bg-neutral-900 text-white border-neutral-800"
      }`}>
        Falar no WhatsApp
      </span>

      {/* Repeating pulsing backdrop animation for notification effect */}
      <div className="absolute right-0 w-14 h-14 bg-emerald-500/30 rounded-full animate-ping pointer-events-none" />

      {/* WhatsApp Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Falar conosco no WhatsApp"
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-transform hover:scale-110 active:scale-95 duration-300 relative ${
          highContrast
            ? "bg-white text-black border-2 border-black hover:bg-zinc-200"
            : "bg-[#25D366] text-white hover:bg-[#20ba59]"
        }`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className="w-7 h-7"
        >
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.727-1.458L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.967C16.486 1.973 14.022 1.04 11.4 1.04c-5.44 0-9.866 4.372-9.87 9.802 0 1.986.53 3.924 1.536 5.643l-.984 3.591 3.69-.96c1.619.883 3.25 1.341 4.881 1.341zm9.952-6.843c-.272-.136-1.613-.796-1.863-.887-.25-.091-.432-.136-.613.136-.182.271-.704.887-.863 1.069-.159.182-.319.204-.591.069-.272-.136-1.15-.424-2.19-1.353-.809-.722-1.355-1.614-1.514-1.886-.159-.271-.017-.419.119-.554.123-.122.272-.319.409-.478.136-.159.182-.272.272-.453.091-.182.045-.341-.023-.478-.068-.136-.613-1.477-.84-2.022-.221-.534-.483-.456-.663-.466-.17-.008-.364-.01-.557-.01-.193 0-.508.072-.773.364-.265.291-1.01.986-1.01 2.405 0 1.419 1.033 2.791 1.177 2.984.145.193 2.034 3.104 4.928 4.354.689.297 1.227.473 1.646.606.693.219 1.325.188 1.823.114.556-.083 1.613-.659 1.84-1.295.227-.636.227-1.183.159-1.295-.068-.113-.25-.204-.522-.341z" />
        </svg>
      </a>
    </div>
  );
}
