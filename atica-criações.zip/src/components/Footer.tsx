import React, { useState } from "react";
import { Linkedin, Instagram, Mail, Phone, MapPin, Globe, Shield, Scale, X } from "lucide-react";
import AticaLogo from "./AticaLogo";

interface FooterProps {
  highContrast: boolean;
  onLinkClick: (href: string) => void;
}

export default function Footer({ highContrast, onLinkClick }: FooterProps) {
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);

  // Smooth scroll handler helper
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <footer
      className={`pt-16 pb-12 border-t ${
        highContrast
          ? "bg-black text-white border-white border-t-2"
          : "bg-[#050505] text-white/50 border-white/5"
      }`}
      aria-label="Rodapé Institucional"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-8 pb-12 border-b border-white/5">
          
          {/* Column 1: Logo & Meta Info */}
          <div className="md:col-span-12 lg:col-span-5 flex flex-col space-y-4 text-left">
            <a
              href="#"
              onClick={(e) => handleScrollTo(e, "#root")}
              className="flex items-center self-start focus-visible:ring-2 focus-visible:ring-blue-600 rounded-none py-1"
              aria-label="Atica - Voltar ao Topo"
            >
              <AticaLogo className="h-7 w-auto" highContrast={highContrast} />
            </a>

            <p className="text-xs font-sans font-light leading-relaxed max-w-sm text-white/50">
              Unimos engenharia técnica rigorosa de software com inteligência de marketing de conversão B2B. Do escopo do protótipo ao traqueamento final de vendas.
            </p>

            {/* Social Icons links */}
            <div className="flex items-center space-x-3 pt-2">
              <a
                href="https://www.linkedin.com/company/atica-criacoes/?viewAsMember=true"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-2 border border-white/5 bg-white/[0.02] hover:border-blue-500/50 hover:bg-white/5 transition-colors text-white/60 hover:text-white`}
                aria-label="Acesse nosso LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://www.instagram.com/atica_criacoes/"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-2 border border-white/5 bg-white/[0.02] hover:border-blue-500/50 hover:bg-white/5 transition-colors text-white/60 hover:text-white`}
                aria-label="Acesse nosso Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="mailto:contato@aticacriacoes.com"
                className={`p-2 border border-white/5 bg-white/[0.02] hover:border-blue-500/50 hover:bg-white/5 transition-colors text-white/60 hover:text-white`}
                aria-label="Envie um e-mail para nós"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Specific services SEO alignment */}
          <div className="md:col-span-6 lg:col-span-3 text-left">
            <h3 className="font-serif font-bold text-white text-sm uppercase tracking-wider mb-4">
              Nossas Soluções
            </h3>
            <ul className="space-y-3 text-xs">
              <li>
                <a
                  href="#solucoes"
                  onClick={(e) => handleScrollTo(e, "#solucoes")}
                  className={`hover:text-blue-400 font-sans font-light transition-colors block ${highContrast ? "underline text-white font-bold" : "text-white/60"}`}
                >
                  Desenvolvimento de Apps
                </a>
              </li>
              <li>
                <a
                  href="#solucoes"
                  onClick={(e) => handleScrollTo(e, "#solucoes")}
                  className={`hover:text-blue-400 font-sans font-light transition-colors block ${highContrast ? "underline text-white font-bold" : "text-white/60"}`}
                >
                  Plataformas Web & UI/UX
                </a>
              </li>
              <li>
                <a
                  href="#solucoes"
                  onClick={(e) => handleScrollTo(e, "#solucoes")}
                  className={`hover:text-blue-400 font-sans font-light transition-colors block ${highContrast ? "underline text-white font-bold" : "text-white/60"}`}
                >
                  Marketing & Performance B2B
                </a>
              </li>
              <li>
                <a
                  href="#solucoes"
                  onClick={(e) => handleScrollTo(e, "#solucoes")}
                  className={`hover:text-blue-400 font-sans font-light transition-colors block ${highContrast ? "underline text-white font-bold" : "text-white/60"}`}
                >
                  SEO & Velocidade Técnica
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Contacts */}
          <div className="md:col-span-6 lg:col-span-4 text-left space-y-4">
            <h3 className="font-serif font-bold text-white text-sm uppercase tracking-wider">
              Canais de Contato
            </h3>
            <ul className="space-y-3.5 text-xs font-sans font-light text-white/60">
              <li className="flex items-center space-x-2.5">
                <Mail className="w-3.5 h-3.5 shrink-0 text-blue-400" />
                <a href="mailto:contato@aticacriacoes.com" className="hover:text-blue-400 transition-colors">
                  contato@aticacriacoes.com
                </a>
              </li>
              <li className="flex items-center space-x-2.5">
                <Phone className="w-3.5 h-3.5 shrink-0 text-blue-400" />
                <a href="https://wa.me/5511970199648?text=Ol%C3%A1%2C%20venho%20do%20site%20da%20Atica%20Cria%C3%A7%C3%B5es%20e%20gostaria%20de%20saber%20mais." target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors">
                  11 97019-9648
                </a>
              </li>
              <li className="flex items-start space-x-2.5">
                <MapPin className="w-3.5 h-3.5 shrink-0 text-blue-400 mt-0.5" />
                <span className="leading-snug">
                  Base em São Paulo/SP
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright metadata row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-sans font-light text-white/40">
          <div className="text-center sm:text-left space-y-1">
            <p>© 2026 Atica Criações Ltda. Todos os direitos reservados.</p>
            <p className="text-[10px] text-white/30">CNPJ: 34.891.092/0001-82 | Registro Comercial Paulistano</p>
          </div>

          <div className="flex items-center space-x-6">
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-blue-400 text-[11px] text-white/45 underline cursor-pointer font-mono uppercase tracking-wider transition-colors"
              aria-label="Ver política de privacidade"
            >
              Privacidade
            </button>
            <button
              onClick={() => setIsTermsOpen(true)}
              className="hover:text-blue-400 text-[11px] text-white/45 underline cursor-pointer font-mono uppercase tracking-wider transition-colors"
              aria-label="Ver termos de uso"
            >
              Termos
            </button>
          </div>
        </div>
      </div>

      {/* Accessible Policy Modal - Privacy Policy */}
      {isPrivacyOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 text-left"
          role="dialog"
          aria-modal="true"
          aria-labelledby="privacy-modal-title"
        >
          <div className={`w-full max-w-xl rounded-none p-6 sm:p-8 shadow-2xl relative border border-white/10 overflow-y-auto max-h-[85vh] ${
            highContrast ? "bg-black border-2 border-white text-white" : "bg-neutral-900 text-white"
          }`}>
            <button
              onClick={() => setIsPrivacyOpen(false)}
              className={`absolute top-4 right-4 p-2 cursor-pointer border border-white/10 hover:bg-white hover:text-black transition-colors ${
                highContrast ? "text-white hover:bg-zinc-800" : "text-white/60"
              }`}
              aria-label="Fechar"
            >
              <X className="w-4 h-4" />
            </button>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2.5 pb-2 border-b border-white/10">
                <Shield className="w-4 h-4 text-blue-500" />
                <h3 id="privacy-modal-title" className="text-lg font-serif font-black text-white">
                  Política de Privacidade
                </h3>
              </div>
              <p className="text-[9px] font-mono text-blue-400 uppercase tracking-widest">Última atualização: Junho 2026</p>
              
              <div className="space-y-3.5 text-xs font-sans font-light leading-relaxed max-h-[45vh] overflow-y-auto pr-2 text-white/70">
                <p>
                  A Atica Criações valoriza a privacidade e segurança de seus usuários e potenciais clientes. Coletamos informações de contato corporativos exclusivamente após preenchimento explícito do formulário para elaboração de propostas e orçamentos.
                </p>
                <h4 className="font-bold text-white font-serif uppercase text-[11px] tracking-wide mt-2">1. Natureza dos Dados Coletados</h4>
                <p>
                  Os dados de Nome completo, E-mail corporativo, Telefone com WhatsApp e Descrição do escopo de TI só são retidos se enviados voluntariamente.
                </p>
                <h4 className="font-bold text-white font-serif uppercase text-[11px] tracking-wide mt-2">2. Direitos Sob a LGPD</h4>
                <p>
                  Em conformidade com a Lei Geral de Proteção de Dados (LGPD) brasileira, você tem total garantia de requisitar a consulta, alteração ou eliminação irrestrita de seus registros em nosso banco a qualquer tempo pelo e-mail dpo@aticacriacoes.com.
                </p>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setIsPrivacyOpen(false)}
                  className={`px-6 py-2 border font-mono text-[10px] uppercase tracking-widest transition-all cursor-pointer ${
                    highContrast ? "bg-white text-black border-white" : "border-white/20 hover:bg-white text-white hover:text-black"
                  }`}
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Accessible Policy Modal - Terms */}
      {isTermsOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 text-left"
          role="dialog"
          aria-modal="true"
          aria-labelledby="terms-modal-title"
        >
          <div className={`w-full max-w-xl rounded-none p-6 sm:p-8 shadow-2xl relative border border-white/10 overflow-y-auto max-h-[85vh] ${
            highContrast ? "bg-black border-2 border-white text-white" : "bg-neutral-900 text-white"
          }`}>
            <button
              onClick={() => setIsTermsOpen(false)}
              className={`absolute top-4 right-4 p-2 cursor-pointer border border-white/10 hover:bg-white hover:text-black transition-colors ${
                highContrast ? "text-white" : "text-white/60"
              }`}
              aria-label="Fechar"
            >
              <X className="w-4 h-4" />
            </button>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2.5 pb-2 border-b border-white/10">
                <Scale className="w-4 h-4 text-blue-500" />
                <h3 id="terms-modal-title" className="text-lg font-serif font-black text-white">
                  Termos de Uso
                </h3>
              </div>
              <p className="text-[9px] font-mono text-blue-400 uppercase tracking-widest">Última atualização: Junho 2026</p>
              
              <div className="space-y-3.5 text-xs font-sans font-light leading-relaxed max-h-[45vh] overflow-y-auto pr-2 text-white/70">
                <p>
                  Ao acessar este site da Atica Criações, você concorda com o cumprimento dos termos expostos. Os protótipos de alta definição, imagens concebidas e layouts demonstrativos neste site são de governança intelectual exclusiva da Atica Criações Ltda.
                </p>
                <h4 className="font-bold text-white font-serif uppercase text-[11px] tracking-wide mt-2">1. Utilização Consentida</h4>
                <p>
                  As simulações interativas feitas na hero page visam demonstrar as aptidões técnicas de engenharia, sendo vedada sua extração não autorizada do repositório para fins comerciais diretos.
                </p>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setIsTermsOpen(false)}
                  className={`px-6 py-2 border font-mono text-[10px] uppercase tracking-widest transition-all cursor-pointer ${
                    highContrast ? "bg-white text-black border-white" : "border-white/20 hover:bg-white text-white hover:text-black"
                  }`}
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </footer>
  );
}
