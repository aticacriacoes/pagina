import { Users, Target, Code2, Milestone, ShieldCheck, HeartHandshake } from "lucide-react";

interface AboutUsProps {
  highContrast: boolean;
}

export default function AboutUs({ highContrast }: AboutUsProps) {
  const stats = [
    { value: "+54", label: "Projetos Lançados", detail: "Websites, Apps e SaaS de alta fidelidade" },
    { value: "99.9%", label: "Uptime Garantido", detail: "Infraestrutura escalável sob Docker e Nube" },
    { value: "R$ 15M+", label: "Faturado p/ Clientes", detail: "Com estratégias de performance B2B" },
    { value: "< 1h", label: "Resposta Comercial", detail: "Suporte dedicado com analistas seniores" }
  ];

  return (
    <section
      id="sobre-nos"
      className={`py-20 md:py-28 text-left border-b border-white/5 ${
        highContrast ? "bg-black text-white border-b-2 border-white" : "bg-[#0A0A0A] text-white"
      }`}
      aria-labelledby="about-title"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Column 1: Storytelling */}
          <div className="space-y-6">
            <span className={`font-mono text-blue-500 text-xs tracking-[0.3em] uppercase block ${
              highContrast ? "text-white underline" : ""
            }`}>
              Quem é a Atica Criações
            </span>
            <h2
              id="about-title"
              className="text-3xl sm:text-5xl font-serif font-black tracking-tighter text-white leading-tight"
            >
              Unimos tecnologia profunda com engenharia comercial.
            </h2>
            <p className={`text-base font-sans font-light leading-relaxed ${highContrast ? "text-zinc-200" : "text-white/60"}`}>
              Nascemos para resolver o principal gargalo de empresas no ambiente online: a desconexão gritante entre o time que escreve o código do software e o time que desenha os anúncios comerciais de marketing.
            </p>
            <p className={`text-base font-sans font-light leading-relaxed ${highContrast ? "text-zinc-200" : "text-white/60"}`}>
              Na Atica, as duas pontas conversam desde a fase de protótipo. Garantimos que seu site seja perfeitamente otimizado para o algoritmo do Google, rápido no mobile de qualquer cliente e com fluxos de traqueamento e tags totalmente configurados.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="flex items-start space-x-3">
                <Code2 className={`w-5 h-5 shrink-0 mt-0.5 ${highContrast ? "text-white" : "text-blue-500"}`} />
                <div>
                  <h4 className="font-bold text-sm text-white font-mono uppercase tracking-wider">Código Sem Legados</h4>
                  <p className="text-xs text-white/40 font-light font-sans mt-0.5">Sempre atualizado com as melhores bibliotecas web.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <HeartHandshake className={`w-5 h-5 shrink-0 mt-0.5 ${highContrast ? "text-white" : "text-blue-500"}`} />
                <div>
                  <h4 className="font-bold text-sm text-white font-mono uppercase tracking-wider">Parceria Duradoura</h4>
                  <p className="text-xs text-white/40 font-light font-sans mt-0.5">Participamos ativamente da evolução estratégica b2b.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Column 2: Bento grid metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {stats.map((st, i) => (
              <div
                key={i}
                className={`p-6 rounded-none border text-center flex flex-col justify-center space-y-2 group hover:border-blue-500/40 transition-all duration-300 ${
                  highContrast
                    ? "bg-black border-2 border-white text-white"
                    : "glass"
                }`}
              >
                <div className="font-serif italic font-black text-3.5xl sm:text-4xl text-blue-500 group-hover:scale-105 transition-transform duration-300">
                  {st.value}
                </div>
                <div className="font-mono text-[10px] uppercase font-bold tracking-wider text-white">{st.label}</div>
                <div className="text-[11px] text-white/40 font-sans font-light leading-snug">{st.detail}</div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}
