import React, { useState, useEffect } from "react";
import { Menu, X, ChevronDown, Sparkles, Accessibility } from "lucide-react";
import AticaLogo from "./AticaLogo";

interface HeaderProps {
  onCtaclick: () => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
}

export default function Header({ onCtaclick, highContrast, setHighContrast }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSolutionsOpen, setIsSolutionsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const menuItems = [
    { label: "Soluções", href: "#solucoes", hasDropdown: true },
    { label: "Metodologia", href: "#metodologia" },
    { label: "Cases", href: "#cases" },
    { label: "Sobre Nós", href: "#sobre-nos" },
  ];

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMenuOpen(false);
    setIsSolutionsOpen(false);
    const element = document.querySelector(href);
    if (element) {
      const offset = 80; // height of fixed header approx
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? highContrast
            ? "bg-black border-b-2 border-white text-white py-3 shadow-md"
            : "bg-[#050505] border-b border-white/10 text-white py-4 shadow-md"
          : highContrast
          ? "bg-black text-white py-5 border-b border-zinc-800"
          : "bg-transparent text-white py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center justify-between" aria-label="Navegação Principal">
          {/* Logo */}
          <a
            href="#"
            onClick={(e) => handleScrollTo(e, "#root")}
            className="flex items-center focus-visible:ring-2 focus-visible:ring-blue-600 rounded-md py-1"
            aria-label="Atica - Home"
          >
            <AticaLogo className="h-8 w-auto" highContrast={highContrast} />
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6">
            <div className="relative">
              <button
                onClick={() => setIsSolutionsOpen(!isSolutionsOpen)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setIsSolutionsOpen(!isSolutionsOpen);
                  }
                }}
                className={`flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.2em] transition-colors hover:text-blue-400 ${
                  isScrolled ? "text-white/80" : "text-white/90"
                } ${highContrast ? "text-white hover:underline" : ""}`}
                aria-expanded={isSolutionsOpen}
                aria-haspopup="true"
              >
                Soluções
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isSolutionsOpen ? "rotate-180" : ""}`} />
              </button>

              {/* Submenu Solutions dropdown */}
              {isSolutionsOpen && (
                <div
                  className={`absolute left-0 mt-3 w-64 rounded-xl p-4 shadow-xl border ${
                    highContrast ? "bg-black border-2 border-white text-white" : "bg-neutral-950/95 border-white/10 text-white backdrop-blur-lg"
                  }`}
                  role="menu"
                  aria-label="Subset de Soluções"
                >
                  <a
                    href="#solucoes"
                    onClick={(e) => handleScrollTo(e, "#solucoes")}
                    className="block p-2 rounded-lg hover:bg-white/5 transition-colors"
                    role="menuitem"
                  >
                    <div className="font-semibold text-sm text-white">Desenvolvimento Móvel</div>
                    <div className="text-xs text-white/50">Android/iOS sob medida</div>
                  </a>
                  <a
                    href="#solucoes"
                    onClick={(e) => handleScrollTo(e, "#solucoes")}
                    className="block p-2 rounded-lg hover:bg-white/5 transition-colors"
                    role="menuitem"
                  >
                    <div className="font-semibold text-sm text-white">Plataformas Web & UI/UX</div>
                    <div className="text-xs text-white/50">Sistemas premium e design visual</div>
                  </a>
                  <a
                    href="#solucoes"
                    onClick={(e) => handleScrollTo(e, "#solucoes")}
                    className="block p-2 rounded-lg hover:bg-white/5 transition-colors"
                    role="menuitem"
                  >
                    <div className="font-semibold text-sm text-white">Marketing & Performance B2B</div>
                    <div className="text-xs text-white/50">Estratégia e atração de leads</div>
                  </a>
                  <a
                    href="#solucoes"
                    onClick={(e) => handleScrollTo(e, "#solucoes")}
                    className="block p-2 rounded-lg hover:bg-white/5 transition-colors"
                    role="menuitem"
                  >
                    <div className="font-semibold text-sm text-white">SEO & Otimização Técnica</div>
                    <div className="text-xs text-white/50">Velocidade máxima e Google ranking</div>
                  </a>
                </div>
              )}
            </div>

            {menuItems.slice(1).map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => handleScrollTo(e, item.href)}
                className={`font-mono text-[11px] uppercase tracking-[0.2em] transition-colors hover:text-blue-400 ${
                  isScrolled ? "text-white/80" : "text-white/90"
                } ${highContrast ? "text-white hover:underline hover:text-white" : ""}`}
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Accessibility & Action controls */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Accessibility Contrast Toggle */}
            <button
              onClick={() => setHighContrast(!highContrast)}
              className={`p-2 rounded-lg transition-colors border ${
                highContrast
                  ? "bg-white text-black border-white"
                  : "bg-white/5 text-white/80 border-white/10 hover:bg-white/15"
              }`}
              title="Alternar Alto Contraste (Acessibilidade)"
              aria-label="Alternar alto contraste"
            >
              <Accessibility className="w-4 h-4" />
            </button>

            <button
              onClick={onCtaclick}
              className={`px-6 py-2 border font-mono text-[11px] uppercase tracking-widest transition-all duration-200 ${
                highContrast
                  ? "bg-white text-black hover:bg-black hover:text-white hover:border-2 hover:border-white"
                  : "border-white/20 hover:bg-white text-white hover:text-black cursor-pointer"
              }`}
            >
              Falar com Especialista
            </button>
          </div>

          {/* Mobile hamburger menu toggle */}
          <div className="flex items-center space-x-2.5 lg:hidden">
            <button
              onClick={() => setHighContrast(!highContrast)}
              className={`p-2 rounded-lg transition-colors border ${
                highContrast
                  ? "bg-white text-black border-white"
                  : "bg-white/5 text-white/90 border-white/10 hover:bg-white/15"
              }`}
              style={{ color: "#FFFFFF" }}
              aria-label="Alternar contraste"
            >
              <Accessibility className="w-4 h-4 text-white" style={{ stroke: "#ffffff" }} />
            </button>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`p-2.5 rounded-lg transition-all border ${
                highContrast 
                  ? "bg-white text-black border-white" 
                  : "bg-white/5 border-white/10 hover:bg-white/15 text-white"
              }`}
              style={{ color: "#FFFFFF" }}
              aria-expanded={isMenuOpen}
              aria-label="Abrir menu de navegação"
            >
              {isMenuOpen ? (
                <X className="w-5.5 h-5.5 text-white" style={{ stroke: "#ffffff", strokeWidth: 2.5 }} />
              ) : (
                <Menu className="w-5.5 h-5.5 text-white" style={{ stroke: "#ffffff", strokeWidth: 2.5 }} />
              )}
            </button>
          </div>
        </nav>
      </div>

      {/* Mobile Drawer Overlay Backdrop */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/80 backdrop-blur-md lg:hidden transition-opacity duration-300"
          onClick={() => setIsMenuOpen(false)}
        />
      )}

      {/* Mobile Drawer */}
      {isMenuOpen && (
        <div
          className={`fixed inset-y-0 right-0 z-50 w-full max-w-xs p-6 shadow-2xl transition-transform duration-300 transform translate-x-0 border-l ${
            highContrast 
              ? "bg-black text-white border-white border-l-2" 
              : "bg-[#0A0A0A] text-white border-white/10"
          }`}
          role="dialog"
          aria-modal="true"
          aria-label="Menu Mobile"
        >
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center">
              <AticaLogo className="h-7 w-auto" highContrast={highContrast} />
            </div>
            <button
              onClick={() => setIsMenuOpen(false)}
              className={`p-2 rounded-full transition-colors ${
                highContrast 
                  ? "bg-white text-black" 
                  : "bg-white/5 hover:bg-white/15 text-white"
              }`}
              aria-label="Fechar menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex flex-col space-y-6">
            <p className="text-[9px] font-mono tracking-[0.25em] uppercase text-white/40">Navegação — Ática</p>
            
            <a
              href="#solucoes"
              onClick={(e) => handleScrollTo(e, "#solucoes")}
              className={`flex items-center text-base font-mono uppercase tracking-wider ${
                highContrast ? "text-white hover:underline" : "text-zinc-100 hover:text-blue-400"
              }`}
            >
              <span className="text-[10px] text-blue-500 mr-2 font-light">01 //</span> Soluções
            </a>
            
            <a
              href="#metodologia"
              onClick={(e) => handleScrollTo(e, "#metodologia")}
              className={`flex items-center text-base font-mono uppercase tracking-wider ${
                highContrast ? "text-white hover:underline" : "text-zinc-100 hover:text-blue-400"
              }`}
            >
              <span className="text-[10px] text-blue-500 mr-2 font-light">02 //</span> Metodologia
            </a>
            
            <a
              href="#cases"
              onClick={(e) => handleScrollTo(e, "#cases")}
              className={`flex items-center text-base font-mono uppercase tracking-wider ${
                highContrast ? "text-white hover:underline" : "text-zinc-100 hover:text-blue-400"
              }`}
            >
              <span className="text-[10px] text-blue-500 mr-2 font-light">03 //</span> Cases
            </a>

            <a
              href="#sobre-nos"
              onClick={(e) => handleScrollTo(e, "#sobre-nos")}
              className={`flex items-center text-base font-mono uppercase tracking-wider ${
                highContrast ? "text-white hover:underline" : "text-zinc-100 hover:text-blue-400"
              }`}
            >
              <span className="text-[10px] text-blue-500 mr-2 font-light">04 //</span> Sobre Nós
            </a>

            <hr className={highContrast ? "border-white" : "border-white/10"} />

            <button
              onClick={() => {
                setIsMenuOpen(false);
                onCtaclick();
              }}
              className={`w-full py-3.5 rounded-none font-mono text-[10px] uppercase tracking-widest font-bold text-center transition-all ${
                highContrast 
                  ? "bg-white text-black hover:bg-black hover:text-white border border-white" 
                  : "bg-blue-600 text-white hover:bg-blue-500 active:scale-95"
              }`}
            >
              Falar com Especialista
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
