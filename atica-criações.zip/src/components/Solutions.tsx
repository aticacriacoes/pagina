import { useState } from "react";
import { Solution } from "../types";
import { Smartphone, MonitorCheck, TrendingUp, Search, CheckCircle2, ArrowRight, X } from "lucide-react";

interface SolutionsProps {
  highContrast: boolean;
}

export default function Solutions({ highContrast }: SolutionsProps) {
  const [selectedSpec, setSelectedSpec] = useState<Solution | null>(null);

  const solutionsData: Solution[] = [
    {
      id: "apps",
      title: "Desenvolvimento de Aplicativos",
      subtitle: "Nativos & Híbridos Premium",
      description: "Construímos aplicativos robustos e sob medida para iOS e Android com sincronização offline, layouts fluídos e experiência nativa.",
      icon: "smartphone",
      features: [
        "Desenvolvimento nativo (Swift/Kotlin) e multiplataforma (React Native/Flutter)",
        "Notificações push inteligentes baseadas em geofencing e comportamento",
        "Arquitetura escalável para alto volume de dados",
        "Sincronização offline transparente com armazenamento seguro local"
      ],
      techStack: ["React Native", "Flutter", "Swift", "Kotlin", "Node.js", "Firebase"]
    },
    {
      id: "web",
      title: "Desenvolvimento Web & UI/UX",
      subtitle: "Plataformas Ultra-Premium",
      description: "Projetamos websites corporativos, SaaS e plataformas web inteligentes de altíssima performance visual, com transições cinematográficas e navegação impecável.",
      icon: "monitor",
      features: [
        "Code splitting avançado e renderização híbrida para velocidade máxima",
        "Interfaces baseadas em design systems consolidados e fluidos",
        "Sistemas administrativos sob medida integrados ao seu ERP",
        "Design 100% responsivo planejado sob o conceito Mobile-First"
      ],
      techStack: ["React", "Vite", "Next.js", "Tailwind CSS", "TypeScript", "Node.js"]
    },
    {
      id: "marketing",
      title: "Marketing Estratégico & Performance",
      subtitle: "Funis e Tração B2B Comercial",
      description: "Estruturamos estratégias de tráfego, Growth hacking e atração inbound focados inteiramente em converter tráfego qualificado em leads corporativos.",
      icon: "marketing",
      features: [
        "Funis de vendas B2B customizados por segmento de mercado",
        "Configuração técnica minuciosa de pixel de rastreio e tracking de conversão",
        "Criação e otimização constante de landing pages com testes A/B",
        "Relatórios dinâmicos integrados com CRMs líderes"
      ],
      techStack: ["Google Ads", "Meta Ads", "LinkedIn Campaign Manager", "Hubspot", "ActiveCampaign"]
    },
    {
      id: "seo",
      title: "SEO & Otimização Técnica",
      subtitle: "Navegação Ultra Veloz e Top Google",
      description: "Posicione o seu negócio nos primeiros resultados de busca do Google para intenções de compra explícitas, aliados a tempos de carregamento impercetíveis.",
      icon: "seo",
      features: [
        "Análise profunda de intenção de busca comercial e palavras-chave de cauda longa",
        "Garantia de atendimento a todos os indicadores Core Web Vitals do Google",
        "Arquitetura de links estruturados interna avançada",
        "Auditoria técnica contínua contra lentidão e barreiras de indexação"
      ],
      techStack: ["Google Search Console", "Screaming Frog", "SemRush", "Lighthouse Otimizador"]
    }
  ];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "smartphone":
        return <Smartphone className={`w-10 h-10 ${highContrast ? "text-white" : "text-blue-600"}`} />;
      case "monitor":
        return <MonitorCheck className={`w-10 h-10 ${highContrast ? "text-white" : "text-blue-600"}`} />;
      case "marketing":
        return <TrendingUp className={`w-10 h-10 ${highContrast ? "text-white" : "text-blue-600"}`} />;
      case "seo":
        return <Search className={`w-10 h-10 ${highContrast ? "text-white" : "text-blue-600"}`} />;
      default:
        return <MonitorCheck className="w-10 h-10" />;
    }
  };

  return (
    <section
      id="solucoes"
      className={`py-20 md:py-28 border-b border-white/5 ${
        highContrast ? "bg-black text-white" : "bg-[#0A0A0A] text-white"
      }`}
      aria-labelledby="solucoes-title"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 flex flex-col space-y-4">
          <span className={`font-mono text-blue-500 text-xs tracking-[0.3em] uppercase block ${
            highContrast ? "text-white underline" : ""
          }`}>
            Nossas Verticais de Entrega
          </span>
          <h2
            id="solucoes-title"
            className="text-3xl sm:text-5xl font-serif font-black tracking-tighter text-white leading-tight"
          >
            Soluções completas para a evolução digital da sua empresa.
          </h2>
          <p className={`text-base font-sans font-light max-w-2xl mx-auto leading-relaxed ${highContrast ? "text-zinc-300" : "text-white/60"}`}>
            Integramos desenvolvimento ágil, estética impecável de interface e geração qualificada de leads sob uma única governança intelectual.
          </p>
        </div>

        {/* Solutions Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {solutionsData.map((sol) => (
            <div
              key={sol.id}
              onClick={() => setSelectedSpec(sol)}
              className={`p-8 rounded-none border text-left cursor-pointer transition-all duration-300 transform flex flex-col justify-between group hover:border-blue-500/50 ${
                highContrast
                  ? "bg-black border-2 border-white text-white hover:bg-zinc-900"
                  : "glass hover:-translate-y-1"
              }`}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setSelectedSpec(sol);
                }
              }}
              aria-label={`Ver especificações completadas para ${sol.title}`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3.5 border border-white/10 flex items-center justify-center text-blue-500 ${highContrast ? "bg-zinc-800" : "bg-white/5"}`}>
                    {getIcon(sol.icon)}
                  </div>
                  <span className={`font-mono text-[9px] uppercase tracking-widest px-2.5 py-1 border border-white/10 ${
                    highContrast ? "bg-white text-black" : "text-white/40"
                  }`}>
                    {sol.subtitle}
                  </span>
                </div>

                <h3 className="text-xl sm:text-2xl font-serif font-bold tracking-tight text-white group-hover:text-blue-400 transition-colors">
                  {sol.title}
                </h3>

                <p className={`text-sm leading-relaxed font-sans font-light ${highContrast ? "text-zinc-300" : "text-white/50"} line-clamp-3`}>
                  {sol.description}
                </p>
              </div>

              <div className="pt-6 border-t border-white/5 mt-6 flex items-center justify-between">
                <div className="flex flex-wrap gap-1.5 max-w-[70%]">
                  {sol.techStack.slice(0, 3).map((stack) => (
                    <span
                      key={stack}
                      className="text-[9px] font-mono tracking-wider px-2 py-0.5 rounded-none bg-white/5 border border-white/5 text-white/50"
                    >
                      {stack}
                    </span>
                  ))}
                </div>
                <span className={`text-[10px] font-mono uppercase tracking-widest flex items-center gap-1.5 ${
                  highContrast ? "text-white underline" : "text-blue-500 group-hover:translate-x-1"
                }`}>
                  Info <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Modal for detail specification analysis (High-fidelity detailed lookup) */}
        {selectedSpec && (
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-solution-title"
          >
            <div
              className={`w-full max-w-2xl rounded-none p-6 sm:p-8 shadow-2xl relative transition-all border border-white/10 overflow-y-auto max-h-[90vh] ${
                highContrast ? "bg-black text-white border-2 border-white" : "bg-neutral-900 text-white"
              }`}
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedSpec(null)}
                className={`absolute top-4 right-4 p-2 cursor-pointer border border-white/10 hover:bg-white hover:text-black transition-colors ${
                  highContrast ? "text-white hover:bg-zinc-850" : "text-white/60"
                }`}
                aria-label="Fechar especificações"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="space-y-6">
                <div className="flex items-center space-x-4 font-sans">
                  <div className={`p-3 border border-white/10 flex items-center justify-center text-blue-500 ${highContrast ? "bg-zinc-850" : "bg-white/5"}`}>
                    {getIcon(selectedSpec.icon)}
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-blue-500">{selectedSpec.subtitle}</span>
                    <h3 id="modal-solution-title" className="text-2xl font-serif font-black text-white">
                      {selectedSpec.title}
                    </h3>
                  </div>
                </div>

                <p className={`text-sm leading-relaxed font-sans font-light ${highContrast ? "text-zinc-250" : "text-white/70"}`}>
                  {selectedSpec.description}
                </p>

                {/* Sub Features Bullet points */}
                <div className="space-y-3.5 pt-4">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-widest text-blue-400">
                    Capacidades & Escopo de Tecnologia:
                  </h4>
                  <ul className="grid grid-cols-1 gap-3">
                    {selectedSpec.features.map((feature, i) => (
                      <li key={i} className="flex items-start space-x-2.5 text-sm font-light text-white/80">
                        <CheckCircle2 className={`w-4 h-4 shrink-0 mt-0.5 ${
                          highContrast ? "text-white" : "text-blue-500"
                        }`} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tech Badges Stack */}
                <div className="pt-4 border-t border-white/10 flex flex-col space-y-2">
                  <h4 className="text-[10px] font-mono font-bold uppercase tracking-widest text-white/40">
                    Stack Técnico Recomendado / Homologado:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedSpec.techStack.map((tech) => (
                      <span
                        key={tech}
                        className={`text-[10px] px-3 py-1 font-mono rounded-none font-bold ${
                          highContrast
                            ? "bg-white text-black border border-white"
                            : "bg-white/5 text-blue-400 border border-white/10"
                        }`}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={() => setSelectedSpec(null)}
                    className={`px-6 py-2 border font-mono text-[10px] uppercase tracking-widest transition-all cursor-pointer ${
                      highContrast ? "bg-white text-black border-white" : "border-white/20 hover:bg-white text-white hover:text-black"
                    }`}
                  >
                    Fechar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
