import { useState } from "react";
import { Step } from "../types";
import { Cpu, Layers, ArrowRight } from "lucide-react";

interface MethodologyProps {
  highContrast: boolean;
}

export default function Methodology({ highContrast }: MethodologyProps) {
  const [activeStep, setActiveStep] = useState<number>(0);

  const steps: Step[] = [
    {
      number: "01",
      title: "Discovery & UX Prototyping",
      subtitle: "Mapeamento Intelectual & Spec de Arquitetura",
      description: "Nesta etapa, destrinchamos as necessidades complexas do negócio do cliente para conceber wireframes iterados de alta fidelidade. Não escrevemos código sem antes desenhar a jornada ideal de ponta a ponta.",
      details: [
        "Mapeamento avançado de personas e fluxo crítico de conversão do usuário",
        "Protótipos responsivos de alta fidelidade no Figma testados com stakeholders",
        "Documentação técnica minuciosa de endpoints, APIs e integrações de terceiros",
        "Modelagem lógica preliminar e especificação funcional de banco de dados"
      ],
      deliverable: "Wireframes Funcionais no Figma & Especificação Técnica"
    },
    {
      number: "02",
      title: "Desenvolvimento Ágil & Seguro",
      subtitle: "Código Limpo, Moderno & Escalabilidade Máxima",
      description: "Engenheiros formados e treinados desenvolvem seu projeto sob as metodologias ágeis mais rígidas. Escrevemos código limpo, documentado, amparado por testes unitários e com pipelines automatizados de Continuous Integration (CI/CD).",
      details: [
        "Stack moderna e limpa focado em modularidade e componentização",
        "Pipelines automáticos de Build, Linting e Teste no GitHub Actions",
        "Monitoria ativa contra vulnerabilidades (Zero-day vulnerability tracking)",
        "Separação estrita de ambientes de Stagging, Sandbox e Produção"
      ],
      deliverable: "Repositório Git com CI/CD, Container Docker & Deploy Automatizado"
    },
    {
      number: "03",
      title: "Growth, SEO & Performance B2B",
      subtitle: "Lançamento de Sucesso, Posicionamento & Otimização Técnica",
      description: "Colocamos o produto no ar com velocidade técnica impecável e atrelamos funis comerciais robustos de captação de prospects de alto ticket. Garantimos pontuação máxima de PageSpeed para otimizar conversões orgânicas e pagas.",
      details: [
        "Configuração de SEO técnico avançado (schema.json, sitemaps automatizados)",
        "Otimização extrema de imagens, fontes e assets com CDN global",
        "Integração de dashboards de Web Analytics (Google Tag Manager, GA4)",
        "Lançamento assistido em lojas de aplicativos e infraestrutura de nuvem"
      ],
      deliverable: "Análise de SEO Orgânico, Score Lighthouse >95 & Configuração Analytics"
    }
  ];

  return (
    <section
      id="metodologia"
      className={`py-20 md:py-28 relative border-b border-white/5 ${
        highContrast ? "bg-black text-white" : "bg-[#0A0A0A] text-white"
      }`}
      aria-labelledby="metodologia-title"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 flex flex-col space-y-4">
          <span className={`font-mono text-blue-500 text-xs tracking-[0.3em] uppercase block ${
            highContrast ? "text-white underline" : ""
          }`}>
            Nossa Engenharia de Trabalho
          </span>
          <h2
            id="metodologia-title"
            className="text-3xl sm:text-5xl font-serif font-black tracking-tighter text-white leading-tight"
          >
            Como Desenvolvemos: Nossa Metodologia B2B
          </h2>
          <p className={`text-base font-sans font-light max-w-2xl mx-auto leading-relaxed ${highContrast ? "text-zinc-300" : "text-white/60"}`}>
            Uma jornada transparente onde design estratégico, engenharia técnica rigorosa e performance digital conversam em perfeita harmonia.
          </p>
        </div>

        {/* Step-by-Step UI Switcher */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start pt-4">
          
          {/* Timeline numbers navigation (Left side) */}
          <div className="lg:col-span-4 flex flex-col space-y-3">
            {steps.map((step, index) => (
              <button
                key={step.number}
                onClick={() => setActiveStep(index)}
                className={`p-6 rounded-none border text-left transition-all duration-200 cursor-pointer flex items-center space-x-4 ${
                  activeStep === index
                    ? highContrast
                      ? "bg-white text-black border-white"
                      : "bg-blue-600/10 text-white shadow-none border-blue-500"
                    : highContrast
                    ? "bg-black border-zinc-700 text-zinc-400 hover:text-white"
                    : "bg-transparent border-white/5 text-white/50 hover:bg-white/5 hover:text-white"
                }`}
                aria-pressed={activeStep === index}
                aria-label={`Passo ${step.number}: ${step.title}`}
              >
                <span className="font-serif font-bold text-2xl tracking-normal text-blue-500">{step.number}</span>
                <div className="text-left">
                  <h3 className="font-semibold text-sm leading-tight text-white">{step.title}</h3>
                  <p className={`text-xs mt-0.5 font-mono uppercase tracking-[0.1em] ${activeStep === index ? "text-blue-400" : "text-white/30"}`}>
                    {index === 0 ? "Foco em UX" : index === 1 ? "Foco em Stack" : "Prepara para Tráfego"}
                  </p>
                </div>
              </button>
            ))}

            {/* Quick architectural badge */}
            <div className={`p-4 rounded-none border mt-4 hidden lg:block ${
              highContrast ? "border-white bg-black" : "bg-white/[0.02] border-white/5"
            }`}>
              <div className="flex items-center space-x-2.5 mb-2">
                <Cpu className={`w-4 h-4 ${highContrast ? "text-white" : "text-blue-500"}`} />
                <span className="text-xs font-bold uppercase tracking-wider text-white">Comprometimento Técnico</span>
              </div>
              <p className="text-xs text-white/40 font-light leading-normal">
                Nossos fluxos e auditorias seguem as práticas de engenharia do Gartner e do W3C.
              </p>
            </div>
          </div>

          {/* Active step details visualizer (Right side) */}
          <div className={`lg:col-span-8 p-8 sm:p-10 rounded-none border ${
            highContrast ? "bg-black border-2 border-white text-white" : "glass border-white/10"
          }`}>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className={`font-mono text-[9px] uppercase tracking-widest px-2.5 py-1 border border-white/10 ${
                  highContrast ? "bg-white text-black" : "text-white/40"
                }`}>
                  Fase {steps[activeStep].number}
                </span>

                <span className="text-xs font-mono text-white/40 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-blue-500" /> Metodologia Certificada
                </span>
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl sm:text-3.5xl font-serif font-black text-white leading-tight">
                  {steps[activeStep].title}
                </h3>
                <h4 className="text-sm font-mono tracking-wider font-semibold text-blue-500">
                  {steps[activeStep].subtitle}
                </h4>
              </div>

              <p className={`text-sm leading-relaxed font-sans font-light ${highContrast ? "text-zinc-200" : "text-white/70"}`}>
                {steps[activeStep].description}
              </p>

              {/* Bullet list of concrete tasks inside active step */}
              <div className="space-y-3.5 pt-4 border-t border-white/10">
                <h5 className="text-[10px] font-mono font-bold uppercase tracking-widest text-blue-400">
                  O que realizamos nesta etapa técnica:
                </h5>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {steps[activeStep].details.map((detail, idx) => (
                    <li key={idx} className="flex items-start space-x-2 text-xs">
                      <span className="text-blue-500 font-bold shrink-0 mt-0.5">•</span>
                      <span className="text-white/70 font-light leading-snug">{detail}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Concrete Deliverable box */}
              <div className={`p-4 rounded-none flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-6 ${
                highContrast ? "bg-zinc-900 border border-zinc-700" : "bg-white/[0.02] border border-white/5"
              }`}>
                <div>
                  <span className="text-[9px] font-mono uppercase tracking-widest text-white/40">Entregável Consolidado:</span>
                  <div className="font-semibold text-sm text-white">{steps[activeStep].deliverable}</div>
                </div>
                <div className={`px-3 py-1 text-[9px] font-mono uppercase tracking-widest border border-white/10 text-center ${
                  highContrast ? "bg-white text-black" : "bg-emerald-500/10 text-emerald-400"
                }`}>
                  Garantia de Qualidade ✓
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
