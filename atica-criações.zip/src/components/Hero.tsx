import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, ArrowRight, Smartphone, BarChart3, Star, Users, ArrowUpRight, ShieldCheck, Zap } from "lucide-react";

interface HeroProps {
  onStartProjectClick: () => void;
  onViewCasesClick: () => void;
  highContrast: boolean;
}

export default function Hero({ onStartProjectClick, onViewCasesClick, highContrast }: HeroProps) {
  const [activeTab, setActiveTab] = useState<'app' | 'dashboard'>('app');
  const [simulatedRevenue, setSimulatedRevenue] = useState(128450);
  const [conversionRate, setConversionRate] = useState(3.42);

  // Subtle real-time data tick to showcase live capabilities
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulatedRevenue(prev => prev + Math.floor(Math.random() * 45) + 5);
      if (Math.random() > 0.7) {
        setConversionRate(prev => +(prev + (Math.random() * 0.08 - 0.04)).toFixed(2));
      }
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section
      id="hero"
      className={`relative pt-32 pb-20 md:pt-44 md:pb-28 overflow-hidden border-b border-white/5 ${
        highContrast ? "bg-black text-white" : "hero-gradient"
      }`}
    >
      {/* Background decoration */}
      {!highContrast && (
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/4 right-1/4 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-10 left-1/3 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl animate-pulse delay-75" />
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Col 1: Marketing / Text Content */}
          <div className="lg:col-span-7 flex flex-col space-y-6">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center space-x-2 self-start"
            >
              <span className={`font-mono text-blue-500 text-xs tracking-[0.3em] uppercase block`}>
                Tecnologia & Performance B2B
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-[60px] font-serif font-black text-white leading-[1.0] tracking-tight"
            >
              Ideia em <span className={highContrast ? "underline text-white" : "italic text-blue-500"}>plataformas</span> de alto impacto.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className={`text-lg md:text-xl font-sans font-light leading-relaxed max-w-xl ${
                highContrast ? "text-zinc-200" : "text-white/60"
              }`}
            >
              Desenvolvimento sob medida, UI/UX premium e marketing estratégico para acelerar sua jornada digital.
            </motion.p>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4"
            >
              <button
                onClick={onStartProjectClick}
                className={`group px-8 py-4 font-mono font-bold text-center flex items-center justify-center space-x-2 text-xs uppercase tracking-widest transition-all duration-300 rounded-none cursor-pointer ${
                  highContrast
                    ? "bg-white text-black hover:bg-black hover:text-white border-2 border-white"
                    : "bg-blue-600 text-white hover:bg-blue-700 shadow-md"
                }`}
              >
                <span>Iniciar Projeto</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                onClick={onViewCasesClick}
                className={`px-8 py-4 font-mono font-bold text-center text-xs uppercase tracking-widest transition-all rounded-none cursor-pointer ${
                  highContrast
                    ? "bg-black text-white hover:bg-white hover:text-black border-2 border-zinc-700"
                    : "bg-transparent text-white border border-white/20 hover:bg-white/10"
                }`}
              >
                Ver Cases
              </button>
            </motion.div>

            {/* Trust factors */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="pt-8 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 gap-4"
            >
              <div className="flex items-center space-x-2">
                <ShieldCheck className={`w-5 h-5 ${highContrast ? "text-white" : "text-blue-500"}`} />
                <span className="text-xs font-mono font-medium text-white/50 uppercase tracking-wider">Código Seguro</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className={`w-5 h-5 ${highContrast ? "text-white" : "text-blue-500"}`} />
                <span className="text-xs font-mono font-medium text-white/50 uppercase tracking-wider">Performance</span>
              </div>
              <div className="flex items-center space-x-2 col-span-2 sm:col-span-1">
                <Users className={`w-5 h-5 ${highContrast ? "text-white" : "text-blue-500"}`} />
                <span className="text-xs font-mono font-medium text-white/50 uppercase tracking-wider">Tratamento B2B</span>
              </div>
            </motion.div>
          </div>

          {/* Col 2: The Magnificent Interactive Live Mockup Component */}
          <div className="lg:col-span-5 relative w-full flex flex-col items-center">
            {/* Tab controls to change view */}
            <div className={`flex p-1 mb-6 rounded-none border z-20 relative max-w-xs ${
              highContrast ? "bg-black border-white" : "bg-white/[0.02] border-white/10 backdrop-blur-md"
            }`}>
              <button
                onClick={() => setActiveTab('app')}
                className={`py-1.5 px-4 rounded-none text-[10px] font-mono font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 cursor-pointer ${
                  activeTab === 'app'
                    ? highContrast
                      ? "bg-white text-black"
                      : "bg-blue-600 text-white"
                    : "text-white/60 hover:text-white"
                }`}
                aria-pressed={activeTab === 'app'}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Ver App Mobile</span>
              </button>
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`py-1.5 px-4 rounded-none text-[10px] font-mono font-bold uppercase tracking-wider transition-all flex items-center space-x-1.5 cursor-pointer ${
                  activeTab === 'dashboard'
                    ? highContrast
                      ? "bg-white text-black"
                      : "bg-blue-600 text-white"
                    : "text-white/60 hover:text-white"
                }`}
                aria-pressed={activeTab === 'dashboard'}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Web Dashboard</span>
              </button>
            </div>

            {/* The Mockup Display Shell */}
            <div className="relative w-full aspect-[4/5] sm:aspect-square md:aspect-auto md:h-[480px] flex items-center justify-center">
              
              {/* Blur accent glow */}
              {!highContrast && (
                <div className="absolute top-10 right-0 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl z-0" />
              )}
              
              <AnimatePresence mode="wait">
                {activeTab === 'app' ? (
                  /* SMARTPHONE INTERACTIVE COMPONENT */
                  <motion.div
                    key="app-tab"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.4 }}
                    className={`relative w-72 h-[460px] rounded-[32px] p-3 shadow-2xl overflow-hidden relative z-10 ${
                      highContrast ? "border-2 border-white bg-black text-white" : "glass rotate-6"
                    }`}
                  >
                    {/* App Internal Simulated Content */}
                    <div className="w-full h-full bg-[#121212]/95 rounded-[24px] border border-white/5 p-4 flex flex-col gap-3 overflow-y-auto" style={{ scrollbarWidth: 'none' }}>
                      <div className="w-12 h-2 bg-white/20 rounded-full mx-auto shrink-0" />
                      
                      <div className="flex items-center justify-between mb-1 mt-2">
                        <div>
                          <p className="text-[10px] font-mono uppercase tracking-wider text-white/50">Bem-vindo de volta,</p>
                          <h4 className="text-xs font-bold font-serif text-white">Parceiro Atica 👋</h4>
                        </div>
                        <div className="w-7 h-7 bg-white/5 rounded-full flex items-center justify-center font-bold text-xs text-blue-500 border border-white/10">P</div>
                      </div>

                      {/* Micro visual card item */}
                      <div className={`p-4 rounded-xl mb-1 flex flex-col space-y-2 border ${
                        highContrast ? "bg-zinc-900 border-zinc-700" : "bg-blue-650/20 border-blue-500/30 text-white shadow-lg"
                      }`}>
                        <span className="text-[8px] uppercase tracking-[0.2em] font-mono text-blue-400">Performance do App</span>
                        <div className="flex items-baseline justify-between">
                          <span className="text-lg font-bold font-mono leading-none">R$ {simulatedRevenue.toLocaleString('pt-BR')}</span>
                          <span className="text-[8px] font-mono bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-full flex items-center">
                            +12.4% Estável
                          </span>
                        </div>
                        <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 w-3/4 animate-pulse" />
                        </div>
                      </div>

                      {/* Quick analytics card item */}
                      <div className={`p-3 rounded-lg border grid grid-cols-2 gap-2 ${
                        highContrast ? "bg-zinc-900 border-zinc-700" : "bg-white/[0.02] border-white/5"
                      }`}>
                        <div>
                          <span className="text-[8px] text-white/40 font-mono uppercase tracking-wider">Conversão</span>
                          <h5 className="text-xs font-bold font-mono text-white">{conversionRate}%</h5>
                        </div>
                        <div>
                          <span className="text-[8px] text-white/40 font-mono uppercase tracking-wider">Ativos</span>
                          <h5 className="text-xs font-bold font-mono text-white">4.8K sess</h5>
                        </div>
                      </div>

                      {/* Interactive toggle switch simulator inside phone */}
                      <div className={`p-3 rounded-lg border ${
                        highContrast ? "bg-zinc-900 border-zinc-700" : "bg-white/[0.02] border-white/5"
                      }`}>
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-mono uppercase tracking-wider text-white/60">Integração B2B</span>
                          <span className="px-1.5 py-0.5 text-[7px] font-mono font-bold uppercase rounded-sm bg-blue-500/20 text-blue-400 border border-blue-500/30">
                            Ativa
                          </span>
                        </div>
                        <p className="text-[8px] text-white/40 mt-1 leading-normal">Webhooks de alta velocidade sincronizados.</p>
                      </div>

                      {/* Small mock navigation elements */}
                      <div className="mt-auto pt-2 grid grid-cols-4 gap-2 border-t border-white/5 text-center">
                        <div className="flex flex-col items-center">
                          <span className="text-xs">🏠</span>
                          <span className="text-[8px] font-mono uppercase text-white/40">Home</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <span className="text-xs">📊</span>
                          <span className="text-[8px] font-mono uppercase text-white/40">Dados</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <span className="text-xs">⚙️</span>
                          <span className="text-[8px] font-mono uppercase text-white/40">Ajustes</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <span className="text-xs">💬</span>
                          <span className="text-[8px] font-mono uppercase text-white/40">Chat</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  /* WEB DASHBOARD INTERACTIVE COMPONENT */
                  <motion.div
                    key="web-tab"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.4 }}
                    className={`w-full max-w-sm sm:max-w-md h-[430px] rounded-2xl border shadow-2xl overflow-hidden flex flex-col relative z-10 ${
                      highContrast ? "bg-black border-2 border-white text-white" : "glass -rotate-3"
                    }`}
                  >
                    {/* Simulated Web Browser Controls */}
                    <div className="bg-[#121212] border-b border-white/10 px-4 py-3 flex items-center justify-between shrink-0">
                      <div className="flex space-x-1.5">
                        <div className="w-2.5 h-2.5 bg-rose-500 rounded-full" />
                        <div className="w-2.5 h-2.5 bg-amber-500 rounded-full" />
                        <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full" />
                      </div>
                      <div className="bg-white/5 text-[9px] text-white/50 px-6 py-1 rounded-sm text-center font-mono w-2/3 select-none truncate">
                        dashboard.aticacriacoes.com
                      </div>
                      <div className="text-white/30 text-[10px]">▲</div>
                    </div>

                    {/* Dashboard Internal Styled Content */}
                    <div className="flex-1 p-5 flex flex-col space-y-4 select-none overflow-y-auto bg-[#0a0a0af0]" style={{ scrollbarWidth: 'none' }}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-[8px] font-mono text-white/40 tracking-[0.2em] uppercase">Painel Executivo Atica Admin</p>
                          <h3 className="text-sm font-bold font-serif text-white">Sucesso dos Clientes</h3>
                        </div>
                        <span className="bg-emerald-500/10 text-emerald-400 text-[8px] font-mono px-2 py-0.5 border border-emerald-500/20 uppercase tracking-widest">
                          Live
                        </span>
                      </div>

                      {/* KPI Numbers Grid */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/[0.01] border border-white/5 rounded-none p-3.5 flex flex-col space-y-1">
                          <span className="text-[8px] uppercase tracking-wider text-white/40 font-mono">Faturamento</span>
                          <span className="text-base font-bold font-mono text-white">R$ {simulatedRevenue.toLocaleString('pt-BR')}</span>
                          <span className="text-[8px] text-emerald-400 flex items-center font-mono">▲ +18.4%</span>
                        </div>
                        <div className="bg-white/[0.01] border border-white/5 rounded-none p-3.5 flex flex-col space-y-1">
                          <span className="text-[8px] uppercase tracking-wider text-white/40 font-mono">Conversão B2B</span>
                          <span className="text-base font-bold font-mono text-white">{conversionRate}%</span>
                          <span className="text-[8px] text-white/40 flex items-center font-mono">Meta: 3.50%</span>
                        </div>
                      </div>

                      {/* Mock Chart Area */}
                      <div className="bg-white/[0.01] border border-white/5 rounded-none p-3 flex-1 flex flex-col">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[8px] uppercase tracking-widest text-white/40 font-mono">Tráfego Mensal</span>
                          <span className="text-[8px] text-white/30 font-mono">Junho</span>
                        </div>
                        <div className="flex-1 flex items-end justify-between space-x-2 pt-2 h-20">
                          <div className="w-full bg-white/5 h-[30%] hover:bg-blue-500 transition-colors pointer-events-auto" title="Jan" />
                          <div className="w-full bg-white/5 h-[45%] hover:bg-blue-500 transition-colors pointer-events-auto" title="Fev" />
                          <div className="w-full bg-white/5 h-[35%] hover:bg-blue-500 transition-colors pointer-events-auto" title="Mar" />
                          <div className="w-full bg-white/5 h-[70%] hover:bg-blue-500 transition-colors pointer-events-auto" title="Abr" />
                          <div className="w-full bg-blue-600 h-[85%] hover:bg-blue-700 transition-colors pointer-events-auto" title="Mai" />
                          <div className="w-full bg-blue-500 h-[95%] hover:bg-blue-600 transition-colors pointer-events-auto" title="Jun" />
                        </div>
                      </div>

                      <p className="text-[8px] text-white/20 text-center font-mono uppercase tracking-widest">
                        Protocolo HTTP/3 habilitado.
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Decorative side badge floating only in visual theme */}
              {!highContrast && (
                <div className="absolute -bottom-4 right-4 bg-[#111] text-white p-3 rounded-none shadow-lg border border-white/10 flex items-center space-x-3 max-w-xs z-20">
                  <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-500 font-mono font-bold text-xs shrink-0">
                    99
                  </div>
                  <div>
                    <h5 className="font-bold text-[10px] font-mono uppercase tracking-wider text-white">Velocidade 99/100</h5>
                    <p className="text-[8px] text-white/40 font-mono">Métricas Lighthouse.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
