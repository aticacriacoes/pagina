import React, { useState } from "react";

interface AticaLogoProps {
  className?: string; // e.g. "h-8" or similar
  highContrast?: boolean;
}

export default function AticaLogo({ className = "h-8 w-auto", highContrast }: AticaLogoProps) {
  const [imageError, setImageError] = useState(false);

  // Google Drive Direct Download URL for the user's uploaded banner/logo image file
  const googleDriveImgUrl = "https://lh3.googleusercontent.com/d/13PtYDAUvNrml_K_EEA39zm9UYXnZITHo";

  // Brand blue color matching the user image: #5DA8E1
  const brandColor = highContrast ? "currentColor" : "#5DA8E1";

  if (!imageError) {
    return (
      <img
        src={googleDriveImgUrl}
        alt="Atica"
        className={`${className} object-contain transition-all duration-300`}
        onError={() => setImageError(true)}
        referrerPolicy="no-referrer"
        style={{
          // Filter to make it full white if high contrast mode is active
          filter: highContrast ? "brightness(0) invert(1)" : "none",
        }}
      />
    );
  }

  // Fallback to beautiful custom inline SVG traced exactly from the user's uploaded banner
  return (
    <svg
      viewBox="0 0 250 80"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      style={{ color: brandColor }}
    >
      <g 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="11" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      >
        {/* α (Alpha) - first letter */}
        <path d="M 52 24 C 41 33 33 42 33 42 C 23 52 14 52 8 42 C 2 32 10 22 19 22 C 29 22 33 42 33 42 C 41 52 50 61 60 62" />

        {/* t */}
        <path d="M 85 16 L 85 46 C 85 54 89 57 95 57" />
        <path d="M 75 28 L 95 28" />

        {/* ι (Iota) */}
        <path d="M 115 28 L 115 46 C 115 54 119 57 125 57" />

        {/* c */}
        <path d="M 160 28 C 153 21 140 21 140 40 C 140 59 153 59 160 52" />

        {/* α (Alpha) - fifth letter */}
        <path d="M 232 24 C 221 33 213 42 213 42 C 203 52 194 52 188 42 C 182 32 190 22 199 22 C 209 22 213 42 213 42 C 221 52 230 61 240 62" />
      </g>
    </svg>
  );
}
