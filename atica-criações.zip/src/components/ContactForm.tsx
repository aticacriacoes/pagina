import React, { useState, useRef, useEffect } from "react";
import { ContactData } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Check, Send, AlertCircle, Phone, Sparkles, Building2, ChevronLeft, Calendar } from "lucide-react";

interface ContactFormProps {
  highContrast: boolean;
}

export default function ContactForm({ highContrast }: ContactFormProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [formData, setFormData] = useState<ContactData>({
    name: "",
    email: "",
    phone: "",
    company: "",
    projectFocus: "",
    projectDesc: ""
  });

  const [errors, setErrors] = useState<Partial<Record<keyof ContactData, string>>>({});
  const [isEmailWarning, setIsEmailWarning] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Simple client-side corporate email warning (not blocking)
  useEffect(() => {
    if (formData.email) {
      const personalDomains = ["gmail.com", "hotmail.com", "outlook.com", "yahoo.com", "uol.com.br", "bol.com.br"];
      const emailDomain = formData.email.split("@")[1]?.toLowerCase();
      if (personalDomains.includes(emailDomain)) {
        setIsEmailWarning(true);
      } else {
        setIsEmailWarning(false);
      }
    } else {
      setIsEmailWarning(false);
    }
  }, [formData.email]);

  const validateStep1 = () => {
    const s1Errors: Partial<Record<keyof ContactData, string>> = {};
    if (!formData.name.trim()) s1Errors.name = "Nome completo é obrigatório.";
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      s1Errors.email = "E-mail corporativo é obrigatório.";
    } else if (!emailRegex.test(formData.email)) {
      s1Errors.email = "Insira um formato de e-mail válido.";
    }

    if (!formData.projectFocus) {
      s1Errors.projectFocus = "Selecione o foco principal do seu projeto.";
    }

    setErrors(s1Errors);
    return Object.keys(s1Errors).length === 0;
  };

  const validateStep2 = () => {
    const s2Errors: Partial<Record<keyof ContactData, string>> = {};
    if (!formData.phone.trim()) s2Errors.phone = "Telefone de contato é obrigatório.";
    if (!formData.company.trim()) s2Errors.company = "Nome da empresa corporativa é obrigatório.";
    if (!formData.projectDesc.trim() || formData.projectDesc.length < 10) {
      s2Errors.projectDesc = "Forneça uma breve descrição do escopo (mínimo 10 caracteres).";
    }

    setErrors(s2Errors);
    return Object.keys(s2Errors).length === 0;
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep1()) {
      setStep(2);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep2()) {
      const subject = encodeURIComponent(`[Contato Site] Novo Escopo de Projeto - ${formData.company}`);
      const body = encodeURIComponent(
        `Olá Atica Criações,\n\n` +
        `Gostaria de solicitar um orçamento para o seguinte projeto:\n\n` +
        `• Nome Completo: ${formData.name}\n` +
        `• E-mail: ${formData.email}\n` +
        `• WhatsApp/Telefone: ${formData.phone}\n` +
        `• Nome da Empresa: ${formData.company}\n` +
        `• Foco do Projeto: ${formData.projectFocus === 'app' ? 'Aplicativo Móvel' : formData.projectFocus === 'web' ? 'Plataforma Web / UI/UX' : 'Performance e Marketing'}\n\n` +
        `• Descrição do Escopo:\n${formData.projectDesc}\n\n` +
        `Atenciosamente,\n${formData.name}`
      );

      // Trigger standard email client with pre-filled content
      window.location.href = `mailto:contato@aticacriacoes.com?subject=${subject}&body=${body}`;
      
      setStep(3);
    }
  };

  return (
    <section
      id="contato"
      ref={sectionRef}
      className={`py-20 md:py-28 border-b border-white/5 ${
        highContrast ? "bg-black text-white border-y-2 border-white" : "bg-[#0A0A0A] text-white"
      }`}
      aria-labelledby="contact-section-title"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column Copywriting */}
          <div className="lg:col-span-6 flex flex-col space-y-6 text-left">
            <span className={`font-mono text-blue-500 text-xs tracking-[0.3em] uppercase block ${
              highContrast ? "text-white underline" : ""
            }`}>
              VAMOS ACELERAR SEU PROJETO
            </span>
            <h2
              id="contact-section-title"
              className="text-4xl sm:text-5xl font-serif font-black leading-tight tracking-tighter text-white"
            >
              Pronto para tirar o seu projeto do papel?
            </h2>
            <p className="text-white/60 font-sans font-light text-base leading-relaxed max-w-lg">
              Fale diretamente com engenheiros de software e especialistas de performance. Desenhamos a arquitetura ideal e um plano comercial sob medida para sua meta.
            </p>

            {/* Support notes */}
            <div className="space-y-4 pt-6 text-xs font-sans font-light text-white/60">
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 rounded-none bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">✓</div>
                <span>Tempo médio de resposta de <strong>1 hora comercial</strong></span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 rounded-none bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20">✓</div>
                <span>NDAs (Acordo de Sigilo) garantidos para ideias inovadoras</span>
              </div>
            </div>
          </div>

          {/* Right Column Intelligent Multi-step Form Grid */}
          <div className="lg:col-span-6">
            <div className={`p-6 sm:p-10 rounded-none border ${
              highContrast ? "bg-black border-2 border-white text-white" : "glass"
            }`}>
              {/* Form Progress steps indicators */}
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/5 select-none">
                <div className="flex items-center space-x-2">
                  <span className={`w-5 h-5 rounded-none flex items-center justify-center text-[10px] font-mono ${
                    step >= 1 ? "bg-blue-600 text-white" : "bg-white/10 text-white/40"
                  }`}>1</span>
                  <span className="text-[10px] font-mono tracking-wider uppercase text-white/60">Contatos</span>
                </div>
                <div className="w-12 h-px bg-white/5" />
                <div className="flex items-center space-x-2">
                  <span className={`w-5 h-5 rounded-none flex items-center justify-center text-[10px] font-mono ${
                    step >= 2 ? "bg-blue-600 text-white" : "bg-white/10 text-white/40"
                  }`}>2</span>
                  <span className={`text-[10px] font-mono tracking-wider uppercase ${step >= 2 ? "text-white/80" : "text-white/40"}`}>Escopo</span>
                </div>
                <div className="w-12 h-px bg-white/5" />
                <div className="flex items-center space-x-2">
                  <span className={`w-5 h-5 rounded-none flex items-center justify-center text-[10px] font-mono ${
                    step === 3 ? "bg-emerald-600 text-white" : "bg-white/10 text-white/40"
                  }`}>3</span>
                  <span className={`text-[10px] font-mono tracking-wider uppercase ${step === 3 ? "text-white/80" : "text-white/40"}`}>Sucesso</span>
                </div>
              </div>

              <AnimatePresence mode="wait">
                {step === 1 && (
                  /* STEP 1: Identification & Project Focus */
                  <motion.form
                    key="step-1"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    onSubmit={handleNext}
                    className="space-y-6 text-left"
                    noValidate
                  >
                    {/* Name */}
                    <div>
                      <label htmlFor="form_name" className="block text-xs font-mono uppercase tracking-widest text-white/50 mb-2">
                        Nome Completo <span className="text-red-400">*</span>
                      </label>
                      <input
                        id="form_name"
                        type="text"
                        placeholder="Ex: João da Silva"
                        value={formData.name}
                        onChange={(e) => {
                          setFormData({ ...formData, name: e.target.value });
                          if (errors.name) setErrors({ ...errors, name: "" });
                        }}
                        className={`w-full py-3 px-4 rounded-none text-xs font-mono tracking-wide border focus:outline-none transition-all ${
                          highContrast
                            ? "bg-black border-white text-white focus:ring-2 focus:ring-white"
                            : "bg-white/[0.02] border-white/10 text-white focus:bg-white/5 focus:border-blue-500/50"
                        } ${errors.name ? "border-red-400 bg-red-400/5" : ""}`}
                        required
                      />
                      {errors.name && (
                        <p className="text-red-400 font-mono text-[10px] mt-1.5 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {errors.name}</p>
                      )}
                    </div>

                    {/* Email Corporativo */}
                    <div>
                      <label htmlFor="form_email" className="block text-xs font-mono uppercase tracking-widest text-white/50 mb-2">
                        E-mail Corporativo <span className="text-red-400">*</span>
                      </label>
                      <input
                        id="form_email"
                        type="email"
                        placeholder="Ex: joao@suaempresa.com.br"
                        value={formData.email}
                        onChange={(e) => {
                          setFormData({ ...formData, email: e.target.value });
                          if (errors.email) setErrors({ ...errors, email: "" });
                        }}
                        className={`w-full py-3 px-4 rounded-none text-xs font-mono tracking-wide border focus:outline-none transition-all ${
                          highContrast
                            ? "bg-black border-white text-white focus:ring-2 focus:ring-white"
                            : "bg-white/[0.02] border-white/10 text-white focus:bg-white/5 focus:border-blue-500/50"
                        } ${errors.email ? "border-red-400 bg-red-400/5" : ""}`}
                        required
                      />
                      {errors.email && (
                        <p className="text-red-400 font-mono text-[10px] mt-1.5 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {errors.email}</p>
                      )}
                      
                      {/* Smooth client warning warning for public emails */}
                      {isEmailWarning && !errors.email && (
                        <div className={`p-3 rounded-none border text-[10px] tracking-wide font-sans mt-2 flex items-start space-x-1.5 ${
                          highContrast ? "bg-zinc-900 border-white text-white" : "bg-blue-950/45 border-blue-500/10 text-blue-300"
                        }`}>
                          <AlertCircle className="w-4 h-4 shrink-0 text-blue-500" />
                          <span>Dica: Fornecer e-mails corporativos gera retorno prioritário no orçamento!</span>
                        </div>
                      )}
                    </div>

                    {/* Focus project options */}
                    <div>
                      <span className="block text-xs font-mono uppercase tracking-widest text-white/50 mb-3">
                        Qual o foco principal do seu projeto? <span className="text-red-400">*</span>
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        {[
                          { id: "app", label: "Aplicativo" },
                          { id: "web", label: "Site Premium" },
                          { id: "marketing", label: "Marketing" }
                        ].map((opt) => (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => {
                              setFormData({ ...formData, projectFocus: opt.id as any });
                              if (errors.projectFocus) setErrors({ ...errors, projectFocus: "" });
                            }}
                            className={`p-3 rounded-none border font-mono uppercase tracking-widest text-[9px] text-center cursor-pointer transition-all ${
                              formData.projectFocus === opt.id
                                ? highContrast
                                  ? "bg-white text-black border-white text-xs"
                                  : "bg-blue-600 text-white border-blue-500"
                                : highContrast
                                ? "bg-black border-zinc-700 text-zinc-400 hover:text-white"
                                : "bg-transparent border-white/10 text-white/60 hover:bg-white/5 hover:text-white"
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                      {errors.projectFocus && (
                        <p className="text-red-400 font-mono text-[10px] mt-2 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {errors.projectFocus}</p>
                      )}
                    </div>

                    <button
                      type="submit"
                      className={`w-full py-4 rounded-none font-mono text-[11px] uppercase tracking-widest flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                        highContrast
                          ? "bg-white text-black hover:bg-black hover:text-white border-2 border-white"
                          : "bg-blue-600 hover:bg-blue-500 text-white shadow-lg"
                      }`}
                    >
                      <span>Próxima Etapa</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </motion.form>
                )}

                {step === 2 && (
                  /* STEP 2: Qualification Details */
                  <motion.form
                    key="step-2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    onSubmit={handleSubmit}
                    className="space-y-6 text-left"
                    noValidate
                  >
                    <div className="flex items-center space-x-1.5">
                      <button
                        type="button"
                        onClick={() => setStep(1)}
                        className="text-[10px] font-mono uppercase tracking-wider text-white/50 hover:text-white flex items-center select-none cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" /> Voltar
                      </button>
                    </div>

                    {/* Telefone */}
                    <div>
                      <label htmlFor="form_phone" className="block text-xs font-mono uppercase tracking-widest text-white/50 mb-2">
                        Telefone Comercial / WhatsApp <span className="text-red-400">*</span>
                      </label>
                      <input
                        id="form_phone"
                        type="text"
                        placeholder="Ex: (11) 99999-9999"
                        value={formData.phone}
                        onChange={(e) => {
                          setFormData({ ...formData, phone: e.target.value });
                          if (errors.phone) setErrors({ ...errors, phone: "" });
                        }}
                        className={`w-full py-3 px-4 rounded-none text-xs font-mono tracking-wide border focus:outline-none transition-all ${
                          highContrast
                            ? "bg-black border-white text-white"
                            : "bg-white/[0.02] border-white/10 text-white focus:bg-white/5 focus:border-blue-500/50"
                        } ${errors.phone ? "border-red-400 bg-red-400/5" : ""}`}
                        required
                      />
                      {errors.phone && (
                        <p className="text-red-400 font-mono text-[10px] mt-1.5 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {errors.phone}</p>
                      )}
                    </div>

                    {/* Nome Corporativo Empresa */}
                    <div>
                      <label htmlFor="form_company" className="block text-xs font-mono uppercase tracking-widest text-white/50 mb-2">
                        Nome da Empresa <span className="text-red-400">*</span>
                      </label>
                      <input
                        id="form_company"
                        type="text"
                        placeholder="Ex: Indústrias Atica S.A."
                        value={formData.company}
                        onChange={(e) => {
                          setFormData({ ...formData, company: e.target.value });
                          if (errors.company) setErrors({ ...errors, company: "" });
                        }}
                        className={`w-full py-3 px-4 rounded-none text-xs font-mono tracking-wide border focus:outline-none transition-all ${
                          highContrast
                            ? "bg-black border-white text-white"
                            : "bg-white/[0.02] border-white/10 text-white focus:bg-white/5 focus:border-blue-500/50"
                        } ${errors.company ? "border-red-400 bg-red-400/5" : ""}`}
                        required
                      />
                      {errors.company && (
                        <p className="text-red-400 font-mono text-[10px] mt-1.5 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {errors.company}</p>
                      )}
                    </div>

                    {/* Descrição do Escopo */}
                    <div>
                      <label htmlFor="form_desc" className="block text-xs font-mono uppercase tracking-widest text-white/50 mb-2">
                        Conte-nos um pouco sobre a sua ideia... <span className="text-red-400">*</span>
                      </label>
                      <textarea
                        id="form_desc"
                        rows={3}
                        placeholder="Ex: Desejamos criar um app de inventário com integração em tempo real e visualização de dashboards corporativos"
                        value={formData.projectDesc}
                        onChange={(e) => {
                          setFormData({ ...formData, projectDesc: e.target.value });
                          if (errors.projectDesc) setErrors({ ...errors, projectDesc: "" });
                        }}
                        className={`w-full py-3 px-4 rounded-none text-xs font-mono tracking-wide border focus:outline-none transition-all ${
                          highContrast
                            ? "bg-black border-white text-white"
                            : "bg-white/[0.02] border-white/10 text-white focus:bg-white/5 focus:border-blue-500/50"
                        } ${errors.projectDesc ? "border-red-400 bg-red-400/5" : ""}`}
                        required
                      />
                      {errors.projectDesc && (
                        <p className="text-red-400 font-mono text-[10px] mt-1.5 flex items-center"><AlertCircle className="w-3.5 h-3.5 mr-1" /> {errors.projectDesc}</p>
                      )}
                    </div>

                    <button
                      type="submit"
                      className={`w-full py-4 rounded-none font-mono text-[11px] uppercase tracking-widest flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                        highContrast
                          ? "bg-white text-black hover:bg-black hover:text-white border-2 border-white"
                          : "bg-blue-600 hover:bg-blue-500 text-white shadow-lg"
                      }`}
                    >
                      <span>Enviar Escopo do Projeto</span>
                      <Send className="w-4 h-4 ml-1" />
                    </button>
                  </motion.form>
                )}

                {step === 3 && (
                  /* STEP 3: Celebration/Victory Success state screen */
                  <motion.div
                    key="step-3"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-6 space-y-6"
                    role="alert"
                  >
                    <div className="w-14 h-14 bg-emerald-500/10 text-emerald-400 rounded-none flex items-center justify-center mx-auto mb-2 border border-emerald-500/25">
                      <Check className="w-8 h-8" />
                    </div>

                    <div className="space-y-2">
                      <h3 className="font-serif font-bold text-2xl text-white font-medium">Proposta Preparada!</h3>
                      <p className="text-white/70 text-xs max-w-sm mx-auto font-sans font-light leading-relaxed">
                        Excelente, <strong>{formData.name}</strong>. Os dados do seu projeto foram estruturados para envio direto ao e-mail comercial <strong>contato@aticacriacoes.com</strong>.
                      </p>
                    </div>

                    {/* Resumo formatado com muito estilo */}
                    <div className="bg-white/[0.02] border border-white/10 rounded-none p-4 text-left max-w-sm mx-auto space-y-1.5 text-[11px] text-white/75 font-mono">
                      <div>
                        <strong className="text-blue-400 font-sans">Destinatário:</strong> contato@aticacriacoes.com
                      </div>
                      <div>
                        <strong>Empresa:</strong> {formData.company}
                      </div>
                      <div>
                        <strong>Foco:</strong> {formData.projectFocus === 'app' ? 'Aplicativo' : formData.projectFocus === 'web' ? 'Site Premium' : 'Marketing'}
                      </div>
                      <div>
                        <strong>E-mail: </strong> {formData.email}
                      </div>
                    </div>

                    <p className="text-white/40 text-[10px] text-left max-w-sm mx-auto">
                      * Caso o seu aplicativo de e-mail não tenha aberto automaticamente com o rascunho pronto, clique no botão azul abaixo para enviar.
                    </p>

                    <div className="pt-2 flex flex-col gap-3 max-w-sm mx-auto">
                      <a
                        href={`mailto:contato@aticacriacoes.com?subject=${encodeURIComponent(`[Contato Site] Novo Escopo de Projeto - ${formData.company}`)}&body=${encodeURIComponent(
                          `Olá Atica Criações,\n\n` +
                          `Gostaria de solicitar um orçamento para o seguinte projeto:\n\n` +
                          `• Nome Completo: ${formData.name}\n` +
                          `• E-mail: ${formData.email}\n` +
                          `• WhatsApp/Telefone: ${formData.phone}\n` +
                          `• Nome da Empresa: ${formData.company}\n` +
                          `• Foco do Projeto: ${formData.projectFocus === 'app' ? 'Aplicativo Móvel' : formData.projectFocus === 'web' ? 'Plataforma Web / UI/UX' : 'Performance e Marketing'}\n\n` +
                          `• Descrição do Escopo:\n${formData.projectDesc}\n\n` +
                          `Atenciosamente,\n${formData.name}`
                        )}`}
                        className={`py-3 px-4 rounded-none font-mono text-[10px] uppercase tracking-widest text-center cursor-pointer transition-all ${
                          highContrast
                            ? "bg-white text-black hover:bg-black hover:text-white border-2 border-white"
                            : "bg-blue-600 hover:bg-blue-500 text-white shadow-md font-bold"
                        }`}
                      >
                        Enviar por E-mail Manualmente
                      </a>

                      <button
                        onClick={() => {
                          setStep(1);
                          setFormData({ name: "", email: "", phone: "", company: "", projectFocus: "", projectDesc: "" });
                          setIsEmailWarning(false);
                          setErrors({});
                        }}
                        className={`py-2.5 border font-mono text-[10px] uppercase tracking-widest transition-all cursor-pointer ${
                          highContrast
                            ? "bg-white text-black border-white"
                            : "border-white/20 text-white hover:bg-white/5"
                        }`}
                      >
                        Enviar outro Escopo
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
