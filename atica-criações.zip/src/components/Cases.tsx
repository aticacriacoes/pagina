import { useState } from "react";
import { CaseStudy } from "../types";
import { ArrowRight, Trophy, BarChart3, Star, Zap, Eye, Calendar, User, CornerDownRight, X } from "lucide-react";

interface CasesProps {
  onCtaclick: () => void;
  highContrast: boolean;
}

export default function Cases({ onCtaclick, highContrast }: CasesProps) {
  const [filter, setFilter] = useState<'all' | 'app' | 'web' | 'marketing'>('all');
  const [selectedCase, setSelectedCase] = useState<CaseStudy | null>(null);

  const casesData: CaseStudy[] = [
    {
      id: "case-1",
      client: "VeloRoute Logística",
      segment: "Transportes & Supply Chain B2B",
      metric: "+140%",
      metricLabel: "Em Produtividade de Distribuição",
      title: "Aplicativo móvel integrado para controle de frotas e assinaturas eletrônicas",
      description: "Desenvolvemos um aplicativo híbrido de alta performance com processamento offline para motoristas rastrearem entregas com extrema precisão em zonas rurais.",
      challenge: "A empresa enfrentava atrasos críticos e perda de dados de rotas devido à instabilidade na conexão dos motoristas com a rede 4G operacional.",
      solution: "Estruturamos um app móvel React Native com fila offline inteligente (IndexDB e SQLite local) que sincroniza automaticamente as coordenadas GPS do trajeto quando há sinal.",
      results: [
        "Economia de combustível em 22% com rotas inteligentes.",
        "Nenhuma entrega perdida por falta de rede móvel.",
        "Lançamento em tempo recorde de 9 semanas nas lojas de aplicativos."
      ],
      type: "app",
      imageUrl: "🚚"
    },
    {
      id: "case-2",
      client: "NeonPay Financeira",
      segment: "Fintech & Crédito Corporativo",
      metric: "Score 99",
      metricLabel: "Velocidade no Google PageSpeed",
      title: "Plataforma web de conversão de leads e simulação de taxas creditícias",
      description: "Reformulamos a interface web institucional e o simulador interativo de crédito para garantir tempo de resposta de milissegundos e elevar as taxas de conversão.",
      challenge: "A lentidão técnica no carregamento mobile afastava 42% dos diretores financeiros que buscavam simular taxas diretamente de anúncios de tráfego pago.",
      solution: "Desenvolvimento de plataforma SPA moderna, eliminando scripts bloqueadores, com pré-renderização estática e CDN otimizado no edge operacional.",
      results: [
        "Aumento expressivo de +84% nas simulações completas de taxas B2B.",
        "Redução drástica do Bounce Rate (taxa de rejeição) em 35%.",
        "Atingiu Score máximo do Lighthouse do Google em Performance."
      ],
      type: "web",
      imageUrl: "💳"
    },
    {
      id: "case-3",
      client: "MestreEduca B2B",
      segment: "Educação Corporativa & Treinamentos",
      metric: "4.2x",
      metricLabel: "Mais Reuniões Agendadas no Funil",
      title: "Estratégia integrada de tráfego orgânico, SEO de intenção e Inbound Marketing",
      description: "Planejamos e implementamos o ecossistema comercial digital para captação automática de executivos de RH em busca de portais de e-learning escaláveis.",
      challenge: "O custo de aquisição de clientes (CAC) estava impraticável, sustentado apenas por contatos telefônicos frios sem engajamento preliminar.",
      solution: "Criamos funis educativos com e-books automatizados, associados a artigos de blog profundamente otimizados em SEO técnico e anúncios direcionados no LinkedIn.",
      results: [
        "Redução de 45% no Custo por Lead Qualificado (CPL).",
        "Atração de 3 grandes contas de Enterprise originadas do tráfego orgânico.",
        "Estruturação de fluxo automatizado diretamente para o HubSpot CRM."
      ],
      type: "marketing",
      imageUrl: "🎓"
    }
  ];

  const filteredCases = filter === 'all'
    ? casesData
    : casesData.filter(c => c.type === filter);

  return (
    <section
      id="cases"
      className={`py-20 md:py-28 border-b border-white/5 ${
        highContrast ? "bg-black text-white border-b-2 border-white" : "bg-[#0A0A0A] text-white"
      }`}
      aria-labelledby="cases-title"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl flex flex-col space-y-4">
            <span className={`font-mono text-blue-500 text-xs tracking-[0.3em] uppercase block ${
              highContrast ? "text-white underline" : ""
            }`}>
              Cases Corporativos de Sucesso
            </span>
            <h2
              id="cases-title"
              className="text-3xl sm:text-5xl font-serif font-black tracking-tighter text-white leading-tight"
            >
              Resultados reais gerados para nossos clientes.
            </h2>
            <p className={`text-base font-sans font-light ${highContrast ? "text-zinc-300" : "text-white/60"}`}>
              Estudos de caso minuciosos mostrando como unificamos rigor de engenharia técnica com estratégias comerciais de captação.
            </p>
          </div>

          {/* Filter options buttons */}
          <div className="flex flex-wrap gap-2 shrink-0">
            {[
              { id: 'all', label: 'Todos os Cases' },
              { id: 'app', label: 'Aplicativos' },
              { id: 'web', label: 'Web & UI/UX' },
              { id: 'marketing', label: 'Performance' },
            ].map((btn) => (
              <button
                key={btn.id}
                onClick={() => setFilter(btn.id as any)}
                className={`px-4 py-2 rounded-none font-mono text-[10px] uppercase tracking-widest transition-all cursor-pointer ${
                  filter === btn.id
                    ? highContrast
                      ? "bg-white text-black"
                      : "bg-blue-600 border border-blue-500 text-white"
                    : highContrast
                    ? "text-zinc-400 hover:text-white border border-zinc-700 bg-zinc-900"
                    : "bg-transparent text-white/70 border border-white/10 hover:border-white/30 hover:bg-white/5"
                }`}
                aria-pressed={filter === btn.id}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>

        {/* Target Cases Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredCases.map((cs) => (
            <div
              key={cs.id}
              className={`rounded-none border overflow-hidden flex flex-col justify-between transition-all duration-300 group hover:border-blue-500/50 ${
                highContrast
                  ? "bg-black border-2 border-white text-white hover:bg-zinc-950"
                  : "glass hover:-translate-y-1"
              }`}
            >
              <div>
                {/* Visual Cover Accent (Minimalist and elegant representation) */}
                <div className={`p-8 flex items-center justify-between border-b border-white/5 ${
                  highContrast ? "bg-zinc-900 border-b border-zinc-700" : "bg-white/[0.01]"
                }`}>
                  <span className="text-4xl select-none">{cs.imageUrl}</span>
                  <div className="text-right">
                    {/* Giant Performance Metric Label */}
                    <span className="block font-serif italic font-black text-blue-500 text-4xl leading-none">
                      {cs.metric}
                    </span>
                    <span className="text-[9px] uppercase font-mono tracking-widest text-white/40">{cs.metricLabel}</span>
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-4 text-left">
                  <div className="flex items-center space-x-2">
                    <span className="text-[9px] font-mono uppercase tracking-widest text-white/45">{cs.segment}</span>
                  </div>

                  <h3 className="font-serif font-bold text-xl leading-snug text-white group-hover:text-blue-400 transition-colors">
                    {cs.client}
                  </h3>

                  <p className={`text-xs font-sans font-light ${highContrast ? "text-zinc-300" : "text-white/60"} line-clamp-3 leading-relaxed`}>
                    {cs.title}
                  </p>
                </div>
              </div>

              {/* Interaction Details Footer */}
              <div className="p-6 pt-0 border-t border-white/5 mt-4 flex items-center justify-between">
                <button
                  onClick={() => setSelectedCase(cs)}
                  className={`text-[10px] font-mono uppercase tracking-widest flex items-center gap-1.5 cursor-pointer transition-colors ${
                    highContrast ? "text-white underline hover:no-underline" : "text-blue-500 hover:text-blue-400"
                  }`}
                  aria-label={`Ver estudo de caso completo para ${cs.client}`}
                >
                  Estudo de Caso ➔
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Case detail complete lookup Modal (High fidelity information structure) */}
        {selectedCase && (
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="case-modal-title"
          >
            <div
              className={`w-full max-w-2xl rounded-none p-6 sm:p-8 shadow-2xl relative overflow-y-auto max-h-[90vh] text-left border border-white/10 ${
                highContrast ? "bg-black text-white border-2 border-white" : "bg-neutral-900 text-white"
              }`}
            >
              {/* Close icon */}
              <button
                onClick={() => setSelectedCase(null)}
                className={`absolute top-4 right-4 p-2 cursor-pointer border border-white/10 hover:bg-white hover:text-black transition-colors ${
                  highContrast ? "text-white hover:bg-zinc-850" : "text-white/60"
                }`}
                aria-label="Fechar case de sucesso"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="space-y-6">
                <div className="flex items-center space-x-4 pb-4 border-b border-white/10">
                  <span className="text-5xl">{selectedCase.imageUrl}</span>
                  <div>
                    <span className={`text-[10px] font-mono tracking-widest uppercase ${highContrast ? "text-white underline" : "text-blue-400"}`}>
                      {selectedCase.segment}
                    </span>
                    <h3 id="case-modal-title" className="text-2xl font-serif font-black text-white">
                      {selectedCase.client}
                    </h3>
                  </div>
                </div>

                {/* Big Metric Banner */}
                <div className={`p-4 rounded-none flex items-center justify-between border ${
                  highContrast ? "bg-zinc-900 border border-zinc-700" : "bg-white/[0.01] border-white/5"
                }`}>
                  <p className="text-xs font-sans font-light text-white/70 max-w-[60%]">Resultado validado pela equipe técnica de engenharia:</p>
                  <div className="text-center shrink-0">
                    <span className="block text-3xl font-serif italic font-black text-blue-500 leading-none">
                      {selectedCase.metric}
                    </span>
                    <span className="text-[9px] font-mono text-white/40 uppercase tracking-widest">{selectedCase.metricLabel}</span>
                  </div>
                </div>

                {/* Challenge and Solution */}
                <div className="grid grid-cols-1 gap-4 font-sans font-light text-sm">
                  <div>
                    <h4 className="text-[10px] font-mono uppercase tracking-widest text-white/40 mb-1.5 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-blue-500" /> Desafio do Negócio
                    </h4>
                    <p className={`leading-relaxed ${highContrast ? "text-zinc-200" : "text-white/70"}`}>
                      {selectedCase.challenge}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-mono uppercase tracking-widest text-blue-400 mb-1.5 flex items-center gap-1.5">
                      <Trophy className="w-3.5 h-3.5 text-blue-500" /> Solução Implementada pela Atica
                    </h4>
                    <p className={`leading-relaxed ${highContrast ? "text-zinc-200" : "text-white/70"}`}>
                      {selectedCase.solution}
                    </p>
                  </div>
                </div>

                {/* Real results bullets */}
                <div className="space-y-3 pt-4 border-t border-white/10 text-white/80">
                  <h4 className="text-[10px] font-mono uppercase tracking-widest text-blue-400 mb-2">Resultados Concretos:</h4>
                  <ul className="grid grid-cols-1 gap-2.5">
                    {selectedCase.results.map((res, i) => (
                      <li key={i} className="flex items-start space-x-2.5 text-xs font-sans font-light">
                        <CornerDownRight className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                        <span>{res}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Close/Interaction CTA inside modal */}
                <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-end items-stretch sm:items-center">
                  <button
                    onClick={() => {
                      setSelectedCase(null);
                      onCtaclick();
                    }}
                    className={`px-6 py-2.5 border font-mono text-[10px] uppercase tracking-widest transition-all text-center cursor-pointer ${
                      highContrast ? "bg-white text-black" : "bg-blue-600 border-blue-500 text-white hover:bg-blue-500"
                    }`}
                  >
                    Iniciar projeto semelhante
                  </button>
                  <button
                    onClick={() => setSelectedCase(null)}
                    className={`px-6 py-2.5 border font-mono text-[10px] uppercase tracking-widest transition-all text-center cursor-pointer ${
                      highContrast ? "bg-zinc-850 border-white text-white" : "border-white/20 hover:bg-white text-white hover:text-black"
                    }`}
                  >
                    Voltar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
