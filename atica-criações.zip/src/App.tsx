import { useState } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Solutions from "./components/Solutions";
import Methodology from "./components/Methodology";
import Cases from "./components/Cases";
import AboutUs from "./components/AboutUs";
import ContactForm from "./components/ContactForm";
import Footer from "./components/Footer";
import WhatsAppButton from "./components/WhatsAppButton";

export default function App() {
  const [highContrast, setHighContrast] = useState(false);

  // Smooth scroll helper to jump directly to the Two-Step submission Form
  const triggerCtaScroll = () => {
    const contactSection = document.getElementById("contato");
    if (contactSection) {
      const offset = 80; // approximate Header height
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = contactSection.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  // Smooth scroll helper to jump to Cases
  const triggerCasesScroll = () => {
    const casesSection = document.getElementById("cases");
    if (casesSection) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = casesSection.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      highContrast ? "bg-black text-white" : "bg-white text-zinc-900"
    }`}>
      {/* Header / Nav Layout */}
      <Header
        onCtaclick={triggerCtaScroll}
        highContrast={highContrast}
        setHighContrast={setHighContrast}
      />

      <main id="main-content" aria-label="Conteúdo da Home Page da Atica Criações">
        {/* Section 1: Hero (Primeira Dobra) */}
        <Hero
          onStartProjectClick={triggerCtaScroll}
          onViewCasesClick={triggerCasesScroll}
          highContrast={highContrast}
        />

        {/* Section 3: Solutions Grid */}
        <Solutions highContrast={highContrast} />

        {/* Section 4: Technical Methodology Timeline */}
        <Methodology highContrast={highContrast} />

        {/* Section 5: Case Studies Portfolio */}
        <Cases
          onCtaclick={triggerCtaScroll}
          highContrast={highContrast}
        />

        {/* Section 6: About Us Intro */}
        <AboutUs highContrast={highContrast} />

        {/* Section 7: Final Conversion CTA */}
        <ContactForm highContrast={highContrast} />
      </main>

      {/* Section 8: Footer & Legal modalities */}
      <Footer
        highContrast={highContrast}
        onLinkClick={(href) => {
          const element = document.querySelector(href);
          if (element) {
            element.scrollIntoView({ behavior: "smooth" });
          }
        }}
      />

      {/* Floating WhatsApp Button */}
      <WhatsAppButton highContrast={highContrast} />
    </div>
  );
}
