export interface Solution {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string; // Lucide icon name
  features: string[];
  techStack: string[];
}

export interface CaseStudy {
  id: string;
  client: string;
  segment: string;
  metric: string;
  metricLabel: string;
  title: string;
  description: string;
  challenge: string;
  solution: string;
  results: string[];
  type: 'app' | 'web' | 'marketing' | 'seo';
  imageUrl: string;
}

export interface Step {
  number: string;
  title: string;
  subtitle: string;
  description: string;
  details: string[];
  deliverable: string;
}

export interface ContactData {
  name: string;
  email: string;
  phone: string;
  company: string;
  projectFocus: 'app' | 'web' | 'marketing' | 'seo' | '';
  projectDesc: string;
  budget?: string;
}
